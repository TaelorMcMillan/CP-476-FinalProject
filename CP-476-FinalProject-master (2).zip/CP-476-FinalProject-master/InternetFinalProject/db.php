<?php
$host    = "localhost";
$pass    = "";
$user    = "root";
$db_name = "chat";
$conn    = new mysqli($host, $user, $pass, $db_name);

?>